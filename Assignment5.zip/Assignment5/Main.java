
public class Main {

	public static void main(String[] args) {
		
		Developer[] Developer = {
				
				 new SeniorDeveloper("Senior Web Developer","NeangSourkea", 1500, 3),
				 new SeniorDeveloper("Senior JavaScript Developer","kevin", 1500, 1),
				 new SeniorDeveloper("Senior Python Developer","Vatana", 1200, 3),
				 new SeniorDeveloper("Senior Project Developer","Pitou", 1200, 4),
				 new SeniorDeveloper("Senior Web Developer","PanhaRith", 1200, 3),
				 
				 new JunoirDeveloper("Junior Web Designer","Gechsim", 1000, 3),
				 new JunoirDeveloper("Junior PHP Developer","Milla", 1000, 2),
				 new JunoirDeveloper("Junior Java Developer","Vong", 1000, 2),
				 new JunoirDeveloper("Junior Web Developer","Vy", 1000, 2),
				 new JunoirDeveloper("Junior Project Manager","Anna", 1000, 3),
				 
				 new Intern("Web Developer Intern","John", 200, 1),
				 new Intern("Database Developer Intern","Jake", 200, 1),
				 new Intern("Python Developer Intern","Lukaku", 200, 1),
				 new Intern("Android Developer Intern","Ronaldo", 200, 1),
				 new Intern("C++ Developer Intern","Pepe", 200, 1),
				};
				System.out.println(" ==> Developer with a salary more than $1500: ");
				System.out.println("                                                          ");
				for (int i=0; i<Developer.length; i++) {
					if(Developer[i].getSalary()>1500) {
						System.out.println(Developer[i].show()+".");
						System.out.println("==============================================================");
					}
				}
			}
		
		
	}


