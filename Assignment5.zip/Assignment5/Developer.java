
public abstract class Developer {
	protected String job;
	protected String name;
	protected int basicSalary;
	protected int experience;
	
	public Developer(String job, String name, int basicSalary, int experience) {
		this.job = job;
		this.name = name;
		this.basicSalary = basicSalary;
		this.experience = experience;
	}
	
	public String getJob(){
		return job;
	}
	
	public String getName() {
		return name;
	}
	
	public int getBasicSalary() {
		return basicSalary;
	}
	
	public abstract  int getSalary();

	protected abstract String show();




	
	
}

