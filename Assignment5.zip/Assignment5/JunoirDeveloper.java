
public class JunoirDeveloper extends Developer {



	public JunoirDeveloper (String job, String name, int basicSalary, int experience) {
		super(job, name, basicSalary, experience);
		
		
	}
	public int getSalary() {
		return (int) (basicSalary + (basicSalary* experience * 0.2));
	}
	
	
	public String show() {
		return("Name: "+ name +"."+ " I am a "+job+" My salary is "+getSalary()+" My experince "+ experience + " Year");
	}
	



}
