
public class Cone extends Cylinder {
	public double getVolumeCone() 
	{
		return getVolumeCylinder()/3;
	}
	public void getInfoCone() {
		System.out.println("This cone has the radius of "+getRadius()+" , its color is "+getColor()+" ,and its volume is "+getVolumeCone());
	}
}
