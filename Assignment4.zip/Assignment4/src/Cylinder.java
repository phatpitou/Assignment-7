
public class Cylinder extends Circle {
	private double height;
	
	public double getHeight() 
	{
		return height;
	}
	
	public void setHeight(double height) 
	{
		this.height= height;
	}
	public double getVolumeCylinder() 
	{
		return getArea()*height; 
	}
	public void getInfoCylinder() {
		System.out.println("This cylinder has the radius of "+getRadius()+" , its color is "+getColor()+" ,and its volume is "+ getVolumeCylinder());
	}
}
