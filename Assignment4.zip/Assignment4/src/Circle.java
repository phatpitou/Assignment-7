public class Circle {
	 private String color;
	 private  double radius;
	
	public String getColor() 
	{
		return color;
	}
	
	public double getRadius() 
	{
		return radius;
	}
	
	public void setColor(String color) 
	{
		this.color= color;
	}
	
	public void setRadius(double radius) 
	{
		this.radius= radius;
	}
	
	public double getArea()
	{
		return radius * radius * Math.PI;
	}
	public void getInfoCircle(){
		System.out.println("This circle has the radius of "+radius+" ,its color is "+color+" ,and its area is"+getArea());
	}
}
