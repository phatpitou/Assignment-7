
public class Main {

	public static void main(String[] args) {
		Circle a =new Circle();
		a.setColor("red");
		a.setRadius(4.5);
		a.getInfoCircle();
		
		Cylinder b=new Cylinder();
		b.setColor("yellow");
		b.setRadius(3);
		b.setHeight(5);
		b.getInfoCylinder();
		
		Cone c= new Cone();
		c.setColor("green");
		c.setRadius(3);
		c.setHeight(5);
		c.getInfoCone();
		
	}

}
